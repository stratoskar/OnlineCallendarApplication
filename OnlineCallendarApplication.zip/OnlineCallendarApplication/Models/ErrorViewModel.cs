using System;

namespace OnlineCallendarApplication.Models
{
    public class ErrorViewModel
    {
        public string Explain { get; set; }
    }
}
